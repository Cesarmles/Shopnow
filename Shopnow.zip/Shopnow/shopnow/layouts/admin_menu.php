<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú Desplegable en Barra Lateral</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #333;
            padding-top: 20px;
            color: #fff;
        }
        .sidebar a {
            padding: 10px 15px;
            text-decoration: none;
            font-size: 16px;
            color: #fff;
            display: block;
        }
        .sidebar a:hover {
            background-color: #575757;
        }
        .submenu {
            display: none;
            background-color: #444;
        }
        .submenu a {
            padding-left: 30px;
        }
        .submenu-toggle:hover + .submenu {
            display: block;
        }
        .submenu-toggle {
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <ul class="nav">
            <li>
                <a href="admin.php">
                    <i class="glyphicon glyphicon-home"></i>
                    <span>Panel de control</span>
                </a>
            </li>
            <li>
                <a href="#" class="submenu-toggle">
                    <i class="glyphicon glyphicon-user"></i>
                    <span>Accesos</span>
                </a>
                <ul class="submenu">
                    <li><a href="group.php">Administrar grupo</a></li>
                    <li><a href="users.php">Administrar usuarios</a></li>
                </ul>
            </li>
            <li>
                <a href="categorie.php">
                    <i class="glyphicon glyphicon-indent-left"></i>
                    <span>Categorías</span>
                </a>
            </li>
            <li>
                <a href="#" class="submenu-toggle">
                    <i class="glyphicon glyphicon-th-large"></i>
                    <span>Productos</span>
                </a>
                <ul class="submenu">
                    <li><a href="product.php">Administrar productos</a></li>
                    <li><a href="add_product.php">Agregar productos</a></li>
                </ul>
            </li>
            <li>
                <a href="media.php">
                    <i class="glyphicon glyphicon-picture"></i>
                    <span>Media</span>
                </a>
            </li>
            <li>
                <a href="#" class="submenu-toggle">
                    <i class="glyphicon glyphicon-th-list"></i>
                    <span>Ventas</span>
                </a>
                <ul class="submenu">
                    <li><a href="sales.php">Administrar ventas</a></li>
                    <li><a href="add_sale.php">Agregar venta</a></li>
                </ul>
            </li>
            <li>
                <a href="#" class="submenu-toggle">
                    <i class="glyphicon glyphicon-signal"></i>
                    <span>Reporte de ventas</span>
                </a>
                <ul class="submenu">
                    <li><a href="sales_report.php">Ventas por fecha</a></li>
                    <li><a href="monthly_sales.php">Ventas mensuales</a></li>
                    <li><a href="daily_sales.php">Ventas diarias</a></li>
                </ul>
            </li>
        </ul>
    </div>
    <div style="margin-left:25px; padding:20px;">
        <!-- Contenido principal aquí -->
        <h1>Bienvenido al Panel de Control</h1>
        <p>Contenido de la página aquí.</p>
    </div>
</body>
</html>

