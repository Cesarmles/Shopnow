<?php
/**
 * Escapa una cadena para evitar inyecciones XSS.
 *
 * @param string $data La cadena a escapar.
 * @return string La cadena escapada.
 */
function escape($data) {
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

/**
 * Verifica si un usuario está autenticado.
 *
 * @return bool Verdadero si el usuario está autenticado, falso en caso contrario.
 */
function is_authenticated() {
    return isset($_SESSION['user_id']);
}

/**
 * Redirige a una página especificada.
 *
 * @param string $url La URL a la que redirigir.
 * @param bool $permanent Si es verdadero, redirige con un código de estado 301, de lo contrario, 302.
 */
function redirect($url, $permanent = false) {
    header('Location: ' . $url, true, $permanent ? 301 : 302);
    exit();
}

/**
 * Formatea una fecha en un formato legible.
 *
 * @param string $date La fecha en formato Y-m-d.
 * @return string La fecha formateada.
 */
function format_date($date) {
    return date('d M Y', strtotime($date));
}

/**
 * Verifica si una cadena está vacía.
 *
 * @param string $value La cadena a verificar.
 * @return bool Verdadero si la cadena está vacía, falso en caso contrario.
 */
function is_empty($value) {
    return empty(trim($value));
}

/**
 * Valida una dirección de correo electrónico.
 *
 * @param string $email La dirección de correo electrónico a validar.
 * @return bool Verdadero si la dirección es válida, falso en caso contrario.
 */
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Genera un token CSRF para la protección contra ataques CSRF.
 *
 * @return string El token generado.
 */
function generate_csrf_token() {
    return bin2hex(random_bytes(32));
}

/**
 * Verifica el token CSRF.
 *
 * @param string $token El token a verificar.
 * @return bool Verdadero si el token es válido, falso en caso contrario.
 */
function verify_csrf_token($token) {
    return hash_equals($_SESSION['csrf_token'] ?? '', $token);
}
?>
