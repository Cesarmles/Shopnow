<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú Desplegable</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <style>
        .navbar-nav {
            margin: 0;
        }
        .submenu {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .submenu li {
            list-style: none;
        }
        .submenu li a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .submenu li a:hover {
            background-color: #ddd;
        }
        .submenu-toggle:hover + .submenu {
            display: block;
        }
        .navbar-nav > li {
            position: relative;
        }
    </style>
</head>
<body>
    <div class="container">
        <ul class="nav navbar-nav">
            <li>
                <a href="home.php">
                    <i class="glyphicon glyphicon-home"></i>
                    <span>Panel de control</span>
                </a>
            </li>
            <li>
                <a href="#" class="submenu-toggle">
                    <i class="glyphicon glyphicon-th-list"></i>
                    <span>Ventas</span>
                </a>
                <ul class="nav submenu">
                    <li><a href="sales.php">Administrar ventas</a></li>
                    <li><a href="add_sale.php">Agregar venta</a></li>
                </ul>
            </li>
            <li>
                <a href="#" class="submenu-toggle">
                    <i class="glyphicon glyphicon-signal"></i>
                    <span>Reporte de ventas</span>
                </a>
                <ul class="nav submenu">
                    <li><a href="sales_report.php">Ventas por fecha</a></li>
                    <li><a href="monthly_sales.php">Ventas mensuales</a></li>
                    <li><a href="daily_sales.php">Ventas diarias</a></li>
                </ul>
            </li>
        </ul>
    </div>
</body>
</html>
