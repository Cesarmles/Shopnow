<?php
$errors = array(); // Se inicializa un array para almacenar errores.

/*--------------------------------------------------------------*/
/* Función para eliminar caracteres especiales en una cadena 
   para su uso en una consulta SQL
/*--------------------------------------------------------------*/
function real_escape($str){
  global $con;  // Se utiliza una variable global $con (que representa la conexión a la base de datos).
  $escape = mysqli_real_escape_string($con, $str);  // Escapa caracteres especiales para evitar inyecciones SQL.
  return $escape;  // Devuelve la cadena escapada.
}

/*--------------------------------------------------------------*/
/* Función para eliminar caracteres HTML y caracteres especiales
/*--------------------------------------------------------------*/
function remove_junk($str){
  $str = nl2br($str);  // Convierte saltos de línea en etiquetas <br>.
  $str = htmlspecialchars(strip_tags($str, ENT_QUOTES));  // Elimina etiquetas HTML y convierte caracteres especiales.
  return $str;  // Devuelve la cadena limpia.
}

/*--------------------------------------------------------------*/
/* Función para poner en mayúscula la primera letra de una cadena
/*--------------------------------------------------------------*/
function first_character($str){
  $val = str_replace('-', " ", $str);  // Reemplaza los guiones con espacios.
  $val = ucfirst($val);  // Convierte la primera letra a mayúscula.
  return $val;  // Devuelve la cadena modificada.
}

/*--------------------------------------------------------------*/
/* Función para comprobar que los campos de entrada no estén vacíos
/*--------------------------------------------------------------*/
function validate_fields($var){
  global $errors;  // Se utiliza el array global $errors.
  foreach ($var as $field) {
    $val = remove_junk($_POST[$field]);  // Limpia el valor del campo.
    if(isset($val) && $val == ''){  // Si el campo está vacío.
      $errors = $field . " No puede estar en blanco.";  // Guarda el error en el array $errors.
      return $errors;  // Devuelve el error.
    }
  }
}

/*--------------------------------------------------------------*/
/* Función para mostrar mensajes de sesión
   Ej: echo display_msg($message);
/*--------------------------------------------------------------*/
function display_msg($msg =''){
   $output = array();  // Inicializa un array de salida.
   if(!empty($msg)) {  // Si el mensaje no está vacío.
      foreach ($msg as $key => $value) {
         $output  = "<div class=\"alert alert-{$key}\">";  // Construye el HTML para el mensaje.
         $output .= "<a href=\"#\" class=\"close\" data-dismiss=\"alert\">&times;</a>";
         $output .= remove_junk(first_character($value));  // Limpia y formatea el mensaje.
         $output .= "</div>";
      }
      return $output;  // Devuelve el mensaje formateado.
   } else {
     return "";  // Si no hay mensaje, no devuelve nada.
   }
}

/*--------------------------------------------------------------*/
/* Función para redirigir a una URL
/*--------------------------------------------------------------*/
function redirect($url, $permanent = false)
{
    if (headers_sent() === false) {  // Verifica si los encabezados HTTP no han sido enviados.
      // Redirige a la URL especificada. El segundo parámetro indica si es una redirección permanente (301) o temporal (302).
      header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
    }

    exit();  // Termina la ejecución del script.
}

/*--------------------------------------------------------------*/
/* Función para calcular el precio total de venta, compra y beneficio
/*--------------------------------------------------------------*/
function total_price($totals){
   $sum = 0;  // Inicializa la suma del precio de venta.
   $sub = 0;  // Inicializa la suma del precio de compra.
   foreach($totals as $total ){
     $sum += $total['total_saleing_price'];  // Suma el precio total de venta.
     $sub += $total['total_buying_price'];  // Suma el precio total de compra.
     $profit = $sum - $sub;  // Calcula el beneficio.
   }
   return array($sum, $profit);  // Devuelve la suma y el beneficio en un array.
}

/*--------------------------------------------------------------*/
/* Función para mostrar una fecha y hora legibles
/*--------------------------------------------------------------*/
function read_date($str){
     if($str)
      return date('d/m/Y g:i:s a', strtotime($str));  // Devuelve la fecha en formato legible.
     else
      return null;  // Si la cadena está vacía, devuelve null.
}

/*--------------------------------------------------------------*/
/* Función para crear una fecha y hora legible
/*--------------------------------------------------------------*/
function make_date(){
  return strftime("%Y-%m-%d %H:%M:%S", time());  // Devuelve la fecha y hora actual en formato legible.
}

/*--------------------------------------------------------------*/
/* Función para contar el número de identificaciones
/*--------------------------------------------------------------*/
function count_id(){
  static $count = 1;  // Define una variable estática para mantener el conteo.
  return $count++;  // Incrementa y devuelve el valor de $count.
}

/*--------------------------------------------------------------*/
/* Función para crear una cadena aleatoria
/*--------------------------------------------------------------*/
function randString($length = 5)
{
  $str = '';  // Inicializa la cadena.
  $cha = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()_-+=<>?{}[]|";

  for($x = 0; $x < $length; $x++)  // Bucle para generar la cadena aleatoria.
   $str .= $cha[mt_rand(0, strlen($cha) - 1)];  // Añade un carácter aleatorio a la cadena.
  return $str;  // Devuelve la cadena generada.
}
?>
