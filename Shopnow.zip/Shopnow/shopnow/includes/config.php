<?php

  // Define el host de la base de datos, en este caso, 'localhost', lo que significa que la base de datos
  // está alojada en la misma máquina donde se ejecuta el script PHP.
  define( 'DB_HOST', 'localhost' );          // Establece el host de la base de datos

  // Define el nombre de usuario para conectarse a la base de datos, en este caso, 'root'. 'root' es el nombre de usuario
  // predeterminado en muchas instalaciones de MySQL/MariaDB para acceder como administrador.
  define( 'DB_USER', 'root' );             // Establece el nombre de usuario de la base de datos

  // Define la contraseña del usuario para conectarse a la base de datos. Aquí se deja vacío (''),
  // lo que indica que no se ha establecido ninguna contraseña para el usuario 'root'.
  define( 'DB_PASS', '' );             // Establece la contraseña de la base de datos

  // Define el nombre de la base de datos a la que se conectará el script. En este caso, el nombre de la base de datos es 'pos'.
  // Esta base de datos es la que contendrá las tablas y datos para el sistema POS (Point of Sale - Punto de Venta).
  define( 'DB_NAME', 'pos' );        // Establece el nombre de la base de datos

?>
