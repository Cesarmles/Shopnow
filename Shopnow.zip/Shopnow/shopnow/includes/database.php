<?php
// Se incluye el archivo de configuración, que contiene las constantes de la base de datos (DB_HOST, DB_USER, etc.)
require_once(LIB_PATH_INC . DS . "config.php");

class MySqli_DB {

    // Variables privadas y públicas para la conexión y la consulta
    private $con;          // Conexión a la base de datos
    public $query_id;      // ID de la consulta actual

    // Constructor de la clase que se ejecuta automáticamente al crear una instancia de la clase.
    function __construct() {
        $this->db_connect();  // Llama a la función para conectar a la base de datos cuando se crea un objeto de esta clase
    }

    /*--------------------------------------------------------------*/
    /* Función para abrir la conexión a la base de datos
    /*--------------------------------------------------------------*/
    public function db_connect()
    {
        // Se intenta establecer una conexión con la base de datos usando los datos definidos en config.php
        $this->con = mysqli_connect(DB_HOST, DB_USER, DB_PASS);

        // Verifica si la conexión falla, y si es así, termina la ejecución y muestra un mensaje de error.
        if(!$this->con) {
            die("Fallo en la conexión a la base de datos: " . mysqli_connect_error());
        } else {
            // Si la conexión tiene éxito, selecciona la base de datos específica para usar
            $select_db = $this->con->select_db(DB_NAME);
            
            // Verifica si la selección de la base de datos falla, y si es así, muestra un mensaje de error.
            if(!$select_db) {
                die("Fallo en la selección de la base de datos: " . mysqli_connect_error());
            }
        }
    }

    /*--------------------------------------------------------------*/
    /* Función para cerrar la conexión a la base de datos
    /*--------------------------------------------------------------*/
    public function db_disconnect()
    {
        // Verifica si la conexión existe, y si es así, la cierra y elimina la variable de conexión.
        if(isset($this->con)) {
            mysqli_close($this->con);
            unset($this->con);
        }
    }

    /*--------------------------------------------------------------*/
    /* Función para ejecutar una consulta mysqli
    /*--------------------------------------------------------------*/
    public function query($sql)
    {
        // Verifica si la consulta no está vacía y la ejecuta
        if (trim($sql != "")) {
            $this->query_id = $this->con->query($sql);
        }

        // Si la consulta falla, muestra un mensaje de error con la consulta fallida (solo en modo desarrollo)
        if (!$this->query_id) {
            // Solo para modo desarrollador
            die("Error en esta consulta :<pre> " . $sql ."</pre>");
            // Para modo producción
            // die("Error en la consulta");
        }

        return $this->query_id;  // Devuelve el ID de la consulta ejecutada
    }

    /*--------------------------------------------------------------*/
    /* Función para obtener un array de una consulta mysqli
    /*--------------------------------------------------------------*/
    public function fetch_array($statement)
    {
        return mysqli_fetch_array($statement);  // Devuelve un array de la consulta ejecutada
    }

    /*--------------------------------------------------------------*/
    /* Función para obtener un objeto de una consulta mysqli
    /*--------------------------------------------------------------*/
    public function fetch_object($statement)
    {
        return mysqli_fetch_object($statement);  // Devuelve un objeto de la consulta ejecutada
    }

    /*--------------------------------------------------------------*/
    /* Función para obtener un array asociativo de una consulta mysqli
    /*--------------------------------------------------------------*/
    public function fetch_assoc($statement)
    {
        return mysqli_fetch_assoc($statement);  // Devuelve un array asociativo de la consulta ejecutada
    }

    /*--------------------------------------------------------------*/
    /* Función para contar el número de filas de una consulta mysqli
    /*--------------------------------------------------------------*/
    public function num_rows($statement)
    {
        return mysqli_num_rows($statement);  // Devuelve el número de filas de la consulta ejecutada
    }

    /*--------------------------------------------------------------*/
    /* Función para obtener el último ID insertado en una tabla
    /*--------------------------------------------------------------*/
    public function insert_id()
    {
        return mysqli_insert_id($this->con);  // Devuelve el ID del último registro insertado
    }

    /*--------------------------------------------------------------*/
    /* Función para obtener el número de filas afectadas por una consulta
    /*--------------------------------------------------------------*/
    public function affected_rows()
    {
        return mysqli_affected_rows($this->con);  // Devuelve el número de filas afectadas por la última consulta
    }

    /*--------------------------------------------------------------*/
    /* Función para eliminar caracteres especiales de una cadena para usar en una consulta SQL
    /*--------------------------------------------------------------*/
    public function escape($str)
    {
        return $this->con->real_escape_string($str);  // Escapa caracteres especiales para evitar inyecciones SQL
    }

    /*--------------------------------------------------------------*/
    /* Función para ejecutar un bucle while con resultados de una consulta
    /*--------------------------------------------------------------*/
    public function while_loop($loop)
    {
        global $db;
        $results = array();
        while ($result = $this->fetch_array($loop)) {
            $results[] = $result;  // Añade cada resultado al array $results
        }
        return $results;  // Devuelve el array de resultados
    }

}

// Crea una instancia de la clase MySqli_DB para establecer la conexión a la base de datos automáticamente
$db = new MySqli_DB();

?>
